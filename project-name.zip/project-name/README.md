# Weather Forecast 24h — Kryvyi Rih

## Run (quick)
```bash
pip install -r requirements.txt
python src/train.py
python src/convert_to_tfjs.py
python -m http.server 8000
# open http://localhost:8000/web/
```

CSV format in `data/weather_kriviyrih.csv`:
`timestamp,temp_c,humidity,wind_kmh,precip_prob`
