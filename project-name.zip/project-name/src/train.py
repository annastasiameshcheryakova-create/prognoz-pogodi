from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import tensorflow as tf

from dataset import load_weather_csv, clean_and_fill, make_windows, export_scaler_json

def build_model(input_hours: int, n_features: int, horizon: int) -> tf.keras.Model:
    inp = tf.keras.Input(shape=(input_hours, n_features), name="x")
    x = tf.keras.layers.Conv1D(64, 5, padding="same", activation="relu")(inp)
    x = tf.keras.layers.Conv1D(64, 5, padding="same", activation="relu")(x)
    x = tf.keras.layers.GlobalAveragePooling1D()(x)
    x = tf.keras.layers.Dense(128, activation="relu")(x)
    out = tf.keras.layers.Dense(horizon, name="y")(x)
    model = tf.keras.Model(inp, out)
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="mse", metrics=[tf.keras.metrics.MAE])
    return model

def main():
    data_csv = Path("data/weather_kriviyrih.csv")
    out_dir = Path("artifacts")
    out_dir.mkdir(exist_ok=True)

    input_hours = 48
    horizon = 24

    df = load_weather_csv(data_csv)
    df = clean_and_fill(df)

    ds = make_windows(df, input_hours=input_hours, horizon_hours=horizon)

    X, y = ds.X, ds.y
    n = len(X)
    n_train = int(n * 0.8)

    X_train, y_train = X[:n_train], y[:n_train]
    X_val, y_val = X[n_train:], y[n_train:]

    model = build_model(input_hours, X.shape[-1], horizon)

    callbacks = [
        tf.keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True),
        tf.keras.callbacks.ModelCheckpoint(str(out_dir / "keras_model.keras"), save_best_only=True),
    ]

    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=80,
        batch_size=64,
        callbacks=callbacks,
        verbose=1,
    )

    scaler_pack = export_scaler_json(ds.scaler, input_hours=input_hours, horizon_hours=horizon)
    (out_dir / "scaler.json").write_text(json.dumps(scaler_pack, ensure_ascii=False, indent=2), encoding="utf-8")

    print("Saved model:", out_dir / "keras_model.keras")
    print("Saved scaler:", out_dir / "scaler.json")

if __name__ == "__main__":
    main()
