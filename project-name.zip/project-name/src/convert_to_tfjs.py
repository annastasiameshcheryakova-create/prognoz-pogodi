from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

ARTIFACTS_DIR = Path("artifacts")
IN_MODEL = ARTIFACTS_DIR / "keras_model.keras"
IN_SCALER = ARTIFACTS_DIR / "scaler.json"

WEB_DIR = Path("web")
OUT_MODEL_DIR = WEB_DIR / "model"
OUT_SCALER = WEB_DIR / "scaler.json"

def die(msg: str, code: int = 1) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)
    raise SystemExit(code)

def check_inputs() -> None:
    if not IN_MODEL.exists():
        die(f"Не знайдено модель: {IN_MODEL}. Спочатку: python src/train.py")
    if not IN_SCALER.exists():
        die(f"Не знайдено scaler: {IN_SCALER}. Спочатку: python src/train.py")
    try:
        scaler = json.loads(IN_SCALER.read_text(encoding="utf-8"))
    except Exception as e:
        die(f"scaler.json невалідний JSON: {e}")
    required = ["mean","scale","features","input_hours","horizon"]
    missing = [k for k in required if k not in scaler]
    if missing:
        die(f"У scaler.json бракує ключів: {missing}")

def check_tfjs_converter_available() -> None:
    from shutil import which
    if which("tensorflowjs_converter") is None:
        die("Не знайдено tensorflowjs_converter. Встанови: pip install tensorflowjs")

def convert_model() -> None:
    OUT_MODEL_DIR.mkdir(parents=True, exist_ok=True)
    cmd = [
        "tensorflowjs_converter",
        "--input_format=keras",
        "--output_format=tfjs_layers_model",
        str(IN_MODEL),
        str(OUT_MODEL_DIR),
    ]
    print("[INFO] Running:", " ".join(cmd))
    subprocess.check_call(cmd)

def copy_scaler() -> None:
    WEB_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(IN_SCALER, OUT_SCALER)
    print("[INFO] Copied scaler to", OUT_SCALER)

def main() -> None:
    check_inputs()
    check_tfjs_converter_available()
    convert_model()
    copy_scaler()
    print("[OK] TFJS model in", OUT_MODEL_DIR)

if __name__ == "__main__":
    main()
