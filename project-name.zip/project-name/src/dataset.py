from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Dict

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

FEATURES: List[str] = ["temp_c", "humidity", "wind_kmh", "precip_prob"]
TARGET: str = "temp_c"
TIME_COL: str = "timestamp"

@dataclass
class WindowedDataset:
    X: np.ndarray
    y: np.ndarray
    scaler: StandardScaler
    feature_names: List[str]
    input_hours: int
    horizon_hours: int

def load_weather_csv(csv_path: str | Path) -> pd.DataFrame:
    csv_path = Path(csv_path)
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV не знайдено: {csv_path}")
    df = pd.read_csv(csv_path)

    required_cols = [TIME_COL] + FEATURES
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"У CSV бракує колонок: {missing}. Є: {list(df.columns)}")

    df[TIME_COL] = pd.to_datetime(df[TIME_COL], errors="coerce")
    if df[TIME_COL].isna().any():
        bad = df[df[TIME_COL].isna()].head(5)
        raise ValueError(f"Некоректний timestamp у рядках:\n{bad}")

    df = df.sort_values(TIME_COL).reset_index(drop=True)
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("float32")
    return df

def clean_and_fill(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df = df.groupby(TIME_COL, as_index=False)[FEATURES].mean()
    df = df.set_index(TIME_COL).sort_index()

    full_index = pd.date_range(df.index.min(), df.index.max(), freq="H")
    df = df.reindex(full_index)
    df.index.name = TIME_COL

    df[FEATURES] = df[FEATURES].interpolate(method="time", limit_direction="both")
    df[FEATURES] = df[FEATURES].fillna(0.0)

    if "humidity" in df.columns:
        df["humidity"] = df["humidity"].clip(0, 100)
    if "precip_prob" in df.columns:
        df["precip_prob"] = df["precip_prob"].clip(0, 100)

    return df.reset_index()

def make_windows(
    df: pd.DataFrame,
    input_hours: int = 48,
    horizon_hours: int = 24,
    fit_scaler: bool = True,
    scaler: Optional[StandardScaler] = None,
) -> WindowedDataset:
    if len(df) < input_hours + horizon_hours:
        raise ValueError(f"Замало даних: потрібно >= {input_hours + horizon_hours}, є {len(df)}")

    feat = df[FEATURES].to_numpy(dtype=np.float32)
    target = df[TARGET].to_numpy(dtype=np.float32)

    if fit_scaler:
        scaler = StandardScaler()
        feat_scaled = scaler.fit_transform(feat).astype(np.float32)
    else:
        if scaler is None:
            raise ValueError("fit_scaler=False але scaler не переданий")
        feat_scaled = scaler.transform(feat).astype(np.float32)

    X_list, y_list = [], []
    last_start = len(df) - input_hours - horizon_hours
    for start in range(0, last_start + 1):
        X_list.append(feat_scaled[start : start + input_hours])
        y_list.append(target[start + input_hours : start + input_hours + horizon_hours])

    X = np.stack(X_list, axis=0)
    y = np.stack(y_list, axis=0)

    return WindowedDataset(
        X=X, y=y, scaler=scaler, feature_names=FEATURES.copy(),
        input_hours=input_hours, horizon_hours=horizon_hours
    )

def export_scaler_json(scaler: StandardScaler, input_hours: int, horizon_hours: int) -> Dict:
    return {
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "features": FEATURES.copy(),
        "input_hours": int(input_hours),
        "horizon": int(horizon_hours),
    }
